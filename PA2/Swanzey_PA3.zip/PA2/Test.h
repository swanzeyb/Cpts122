
#pragma once

#include <stdbool.h>
#include <stdio.h>

void SaniCheck(bool condition, char* message);

void TestInsert();

void TestDelete();

void TestShuffle();
